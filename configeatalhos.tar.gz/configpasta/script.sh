#!/bin/bash

# Configurações de tema (funciona somente dentro de uma sessão gráfica GNOME ou compatível)
gsettings set org.gnome.desktop.interface gtk-theme "MyBreeze-Dark-GTK"
gsettings set org.gnome.desktop.interface icon-theme "Adwaita"
gsettings set org.gnome.desktop.interface cursor-theme "Adwaita"
gsettings set org.gnome.desktop.interface font-name "Cantarell 11"

# Criar ponto de montagem, se não existir
mkdir -p /mnt/hd2

# Ajustar permissões
chmod 777 /mnt/hd2

# Montar HD
mount /dev/sdb1 /mnt/hd2

# Adicionar ao fstab apenas se ainda não estiver lá
if ! grep -q "UUID=66611ca8-7791-4a23-93d3-dcb7daf5c577" /etc/fstab; then
    echo "UUID=66611ca8-7791-4a23-93d3-dcb7daf5c577  /mnt/hd2  ext4  defaults,noatime  0  2" >> /etc/fstab
fi

# Configuração do Android AVD
# Adicionar apenas se ainda não estiver presente
if ! grep -q "ANDROID_SDK_HOME" /etc/environment; then
    echo "
ANDROID_SDK_HOME=/mnt/hd2/android-avd
ANDROID_AVD_HOME=/mnt/hd2/android-avd/.android/avd
" >> /etc/environment
fi

# Remover o script após execução
rm -- "$0"
