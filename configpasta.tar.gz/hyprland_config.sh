#!/bin/bash

# Aplicando as configurações
dconf write /org/gnome/desktop/interface/gtk-theme "'MyBreeze-Dark-GTK'"
dconf write /org/gnome/desktop/interface/icon-theme "'Adwaita'"
dconf write /org/gnome/desktop/interface/cursor-theme "'Adwaita'"
dconf write /org/gnome/desktop/interface/font-name "'Cantarell 11'"

# Ou utilizando gsettings, se preferir
# gsettings set org.gnome.desktop.interface gtk-theme "MyBreeze-Dark-GTK"
# gsettings set org.gnome.desktop.interface icon-theme "Adwaita"
# gsettings set org.gnome.desktop.interface cursor-theme "Adwaita"
# gsettings set org.gnome.desktop.interface font-name "Cantarell 11"


# Remover a linha do arquivo de configuração do Hyprland que executa esse script
sed -i '/hyprland_config.sh/d' "$HOME/.config/hypr/hyprland.conf"

# Remover o script após a execução
rm -- "$0"
